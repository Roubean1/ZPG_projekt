#pragma once
#include "OpenGL_Include.h"
#include <memory>

class Model
{
private:
    GLuint VAO = 0;
    GLuint VBO = 0;
    int vertexCount = 0;

public:
    Model() = default; // default konstruktor
    Model(size_t vertexCount);
    ~Model();

    void loadModel(const float* vertices, size_t vertexCount);
    void draw();

    // Statick� tov�rn� metoda
    static std::shared_ptr<Model> createModel(const float* vertices, size_t vertexCount) {
        auto m = std::make_shared<Model>(vertexCount);
        m->loadModel(vertices, vertexCount);
        return m;
    }
};
