﻿#include "Model.h";
#include <iostream>

Model::Model(size_t vertexCount) : vertexCount(static_cast<int>(vertexCount)) {}

Model::~Model() {
    if (VBO) glDeleteBuffers(1, &VBO);
    if (VAO) glDeleteVertexArrays(1, &VAO);
}

void Model::loadModel(const float* vertices, size_t vertexCount) {
    this->vertexCount = static_cast<int>(vertexCount);



    if (!vertices) {
        std::cerr << "❌ Model::loadModel - vertices is null!" << std::endl;
        return;
    }
    if (vertexCount == 0) {
        std::cerr << "❌ Model::loadModel - vertexCount is 0!" << std::endl;
        return;
    }

    if (glGenBuffers == nullptr) {
        std::cerr << "❌ OpenGL not initialized before loadModel()!" << std::endl;
        return;
    }

    this->vertexCount = static_cast<int>(vertexCount);
    // VBO
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, vertexCount * sizeof(float), vertices, GL_STATIC_DRAW);

    // VAO
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), nullptr);

    glBindVertexArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void Model::draw() {
    glBindVertexArray(VAO);
    glDrawArrays(GL_TRIANGLES, 0, vertexCount);
    glBindVertexArray(0);
}
