#pragma once
#include "OpenGL_Include.h"
#include "Observer.h"

class Observer;

class Subject
{
private:
	std::vector<Observer*> observers;

public:
	void addObserver(Observer* observer);
	void removeObserver(Observer* observer);
	void notify(int eventType);
};

