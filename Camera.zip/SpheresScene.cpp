#include "SpheresScene.h"

void SpheresScene::init() {
    // Create sphere model
    auto sphereModel = std::make_shared<Model>();
	sphereModel->loadModel(sphere, sizeof(sphere));

    // Create different shaders for each sphere
    std::vector<std::string> shaderTypes = { "constant", "lambert", "phong", "blinn" };
    std::vector<std::pair<std::string, std::string>> shaderFiles = {
        {CONSTANT_VERTEX, CONSTANT_FRAGMENT},
        {LAMBERT_VERTEX, LAMBERT_FRAGMENT},
        {PHONG_VERTEX, PHONG_FRAGMENT},
        {BLINN_VERTEX, BLINN_FRAGMENT}
    };

    // Rozm�st�n� koul� kolem sv�tla (X a Y osy) - sv�tlo je uprost�ed
    std::vector<glm::vec3> positions = {
        glm::vec3(1.0f,  0.0f, 0.0f),  // Vpravo
        glm::vec3(-1.0f,  0.0f, 0.0f),  // Vlevo
        glm::vec3(0.0f,  1.0f, 0.0f),  // Nahoru
        glm::vec3(0.0f, -1.0f, 0.0f)   // Dol�
    };


    glm::vec3 grayColor = glm::vec3(0.8f, 0.8f, 0.8f); // Sv�tle �ed�

    for (int i = 0; i < 4; i++) {
        auto shader = std::make_shared<ShaderProgram>(shaderTypes[i]);
        if (!shader->loadShadersFromFiles(shaderFiles[i].first, shaderFiles[i].second)) {
            std::cerr << "Failed to load " << shaderTypes[i] << " shader!" << std::endl;
            continue;
        }

        shader->use();
        shader->setUniform("objectColor", grayColor); // Nastaven� barvy pro v�echny koule

        auto composite = std::make_shared<CompositeTransform>();
        composite->addTransform(std::make_shared<Translate>(positions[i]));
        composite->addTransform(std::make_shared<Scale>(glm::vec3(0.5f)));

        addObject(DrawableObject(sphereModel, shader, composite));
    }

}

void SpheresScene::update(float deltaTime) {
}

