#include "ForestScene.h"

ForestScene::ForestScene()
    : rng(std::random_device()()), dist(-50.0f, 50.0f) {
}

void ForestScene::init() {
    // Blinn-Phong forest
    auto forestShader = std::make_shared<ShaderProgram>("blinn");
    if (!forestShader->loadShadersFromFiles(BLINN_VERTEX, BLINN_FRAGMENT)) {
        std::cerr << "Failed to load Blinn-Phong shader!" << std::endl;
        return;
    }

    // Lambert shader ground
    auto groundShader = std::make_shared<ShaderProgram>("lambert");
    if (!groundShader->loadShadersFromFiles(LAMBERT_VERTEX, LAMBERT_FRAGMENT)) {
        std::cerr << "Failed to load Lambert shader!" << std::endl;
        return;
    }

    // Create models
    auto treeModel = std::make_shared<Model>();
    treeModel->loadModel(tree, sizeof(tree) / sizeof(float));


    auto bushesModel = std::make_shared<Model>();
	bushesModel->loadModel(bushes, sizeof(bushes) / sizeof(float));

    auto giftModel = std::make_shared<Model>();
	giftModel->loadModel(gift, sizeof(gift) / sizeof(float));

    auto plainModel = std::make_shared<Model>();
	plainModel->loadModel(plain, sizeof(plain) / sizeof(float));

    // Create forest
    createForest();

    // trees
    for (const auto& tree : forestTrees) {
        auto treeShader = std::make_shared<ShaderProgram>("blinn");
        treeShader->loadShadersFromFiles(BLINN_VERTEX, BLINN_FRAGMENT);
        treeShader->use();
        treeShader->setUniform("objectColor", glm::vec3(0.2f, 0.6f, 0.3f)); // Green

        auto composite = std::make_shared<CompositeTransform>();
        composite->addTransform(std::make_shared<Translate>(tree.position));
        composite->addTransform(std::make_shared<Rotate>(
            glm::radians(tree.rotation), glm::vec3(0.0f, 1.0f, 0.0f)));
        composite->addTransform(std::make_shared<Scale>(glm::vec3(tree.scale)));

        auto drawableObj = DrawableObject(treeModel, treeShader, composite);
        addObject(drawableObj);
    }

    // bushes
    for (const auto& bush : forestBushes) {
        auto bushShader = std::make_shared<ShaderProgram>("blinn");
        bushShader->loadShadersFromFiles(BLINN_VERTEX, BLINN_FRAGMENT);
        bushShader->use();
        bushShader->setUniform("objectColor", glm::vec3(0.1f, 0.4f, 0.2f)); // Dark Green

        auto composite = std::make_shared<CompositeTransform>();
        composite->addTransform(std::make_shared<Translate>(bush.position));
        composite->addTransform(std::make_shared<Rotate>(
            glm::radians(bush.rotation), glm::vec3(0.0f, 1.0f, 0.0f)));
        composite->addTransform(std::make_shared<Scale>(glm::vec3(bush.scale)));

        auto drawableObj = DrawableObject(bushesModel, bushShader, composite);
        addObject(drawableObj);
    }

    // ground
    auto groundComposite = std::make_shared<CompositeTransform>();
    groundComposite->addTransform(std::make_shared<Translate>(glm::vec3(0.0f, -2.0f, 0.0f)));
    groundComposite->addTransform(std::make_shared<Scale>(glm::vec3(100.0f, 0.1f, 100.0f)));

    groundShader->use();
    groundShader->setUniform("objectColor", glm::vec3(0.4f, 0.8f, 0.4f)); // Light green
    auto groundObj = DrawableObject(plainModel, groundShader, groundComposite);
    addObject(groundObj);

    // Gifts
    std::vector<glm::vec3> giftPositions = {
        glm::vec3(10.0f, -1.0f, 10.0f),
        glm::vec3(-8.0f, -1.0f, -12.0f),
        glm::vec3(15.0f, -1.0f, -5.0f)
    };

    std::vector<glm::vec3> giftColors = {
        glm::vec3(1.0f, 0.0f, 0.0f),
        glm::vec3(0.0f, 1.0f, 0.0f),
        glm::vec3(0.0f, 0.0f, 1.0f)
    };

    for (size_t i = 0; i < giftPositions.size(); i++) {
        auto giftShader = std::make_shared<ShaderProgram>("phong");
        giftShader->loadShadersFromFiles(PHONG_VERTEX, PHONG_FRAGMENT);
        giftShader->use();
        giftShader->setUniform("objectColor", giftColors[i]);

        auto composite = std::make_shared<CompositeTransform>();
        composite->addTransform(std::make_shared<Translate>(giftPositions[i]));
        composite->addTransform(std::make_shared<Scale>(glm::vec3(0.5f)));

        auto drawableObj = DrawableObject(giftModel, giftShader, composite);
        addObject(drawableObj);
    }

    std::cout << "ComplexScene: Created forest with " << forestTrees.size()
        << " green trees and " << forestBushes.size() << " dark green bushes" << std::endl;
}

void ForestScene::createForest() {
    forestTrees.clear();
    forestBushes.clear();

    // trees
    for (int i = 0; i < 50; i++) {
        TreeData tree;
        tree.position = generateRandomPosition();
        tree.position.y = -1.8f;

        float randomValue = (dist(rng) + 50.0f) / 100.0f;
        tree.scale = 0.7f + randomValue * 0.2f;
        tree.rotation = randomValue * 360.0f;

        bool validPosition = true;
        for (const auto& existingTree : forestTrees) {
            float distance = glm::length(tree.position - existingTree.position);
            if (distance < 3.0f) {
                validPosition = false;
                break;
            }
        }

        if (validPosition) {
            forestTrees.push_back(tree);
        }
        else {
            i--;
        }
    }

    // bushes
    for (int i = 0; i < 30; i++) {
        TreeData bush;
        bush.position = generateRandomPosition();
        bush.position.y = -1.9f;

        float randomValue = (dist(rng) + 50.0f) / 100.0f;
        bush.scale = 0.25f + randomValue * 0.1f;
        bush.rotation = randomValue * 360.0f;

        bool validPosition = true;
        for (const auto& existingTree : forestTrees) {
            float distance = glm::length(bush.position - existingTree.position);
            if (distance < 2.0f) {
                validPosition = false;
                break;
            }
        }

        for (const auto& existingBush : forestBushes) {
            float distance = glm::length(bush.position - existingBush.position);
            if (distance < 1.5f) {
                validPosition = false;
                break;
            }
        }

        if (validPosition) {
            forestBushes.push_back(bush);
        }
    }
}

glm::vec3 ForestScene::generateRandomPosition() {
    float x = dist(rng);
    float z = dist(rng);

    float distanceFromCenter = glm::length(glm::vec2(x, z));
    if (distanceFromCenter > 45.0f) {
        if (static_cast<float>(std::rand()) / RAND_MAX > 0.7f) {
            return generateRandomPosition();
        }
    }

    return glm::vec3(x, 0.0f, z);
}

void ForestScene::update(float deltaTime) {
}