﻿#pragma once
#include "OpenGL_Include.h"
#include "Subject.h"
#include "ShaderProgram.h" // kvůli předání shaderu

class Light : public Subject {
private:
    ShaderProgram* shaderProgram;
    glm::vec3 position;
    glm::vec3 color;

public:
    // --- 🔹 Default konstruktor (funguje i bez shaderu) ---
    Light()
        : shaderProgram(nullptr),
        position(0.0f, 0.0f, 0.0f),
        color(1.0f, 1.0f, 1.0f) {
    }

    // --- 🔹 Konstruktor s parametry ---
    Light(ShaderProgram* shaderProgram,
        glm::vec3 position = glm::vec3(0.0f),
        glm::vec3 color = glm::vec3(1.0f));

    // --- 🔹 Gettery ---
    glm::vec3 getPosition() const { return position; }
    glm::vec3 getColor() const { return color; }

    // --- 🔹 Settery (aktualizují shader) ---
    void setPosition(const glm::vec3& newPosition);
    void setColor(const glm::vec3& newColor);
};
