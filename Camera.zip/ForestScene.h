#pragma once
#include "OpenGL_Include.h"
#include "Scene.h"
#include <random>

class ForestScene : public Scene {
private:
    std::mt19937 rng;
    std::uniform_real_distribution<float> dist;

    struct TreeData {
        glm::vec3 position;
        float scale;
        float rotation;
    };

    std::vector<TreeData> forestTrees;
    std::vector<TreeData> forestBushes;

public:
    ForestScene();
    void init() override;
    void update(float deltaTime) override;

private:
    void createForest();
    glm::vec3 generateRandomPosition();
};