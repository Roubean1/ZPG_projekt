#pragma once
#include "Scene.h"
#include "OpenGL_Include.h"

class TriangleScene : public Scene {
private:
    float rotationAngle = 0.0f;
public:
    void init() override;
    void update(float deltaTime) override;
};