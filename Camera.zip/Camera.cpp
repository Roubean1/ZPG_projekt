#include "Camera.h"
#include "ShaderProgram.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/constants.hpp>
#include <GLFW/glfw3.h>

Camera::Camera(ShaderProgram* shaderProgram)
    : shaderProgram(shaderProgram),
    position(0.0f, 0.0f, 3.0f),
    front(0.0f, 0.0f, -1.0f),
    up(0.0f, 1.0f, 0.0f),
    yaw(-90.0f),
    pitch(0.0f)
{
    // Po inicializaci rovnou vypo�ti matice
    viewMatrix = glm::lookAt(position, position + front, up);
    projectionMatrix = glm::mat4(1.0f);

    // Po vytvo�en� kamery m��e� informovat pozorovatele
    notify(0);
}

glm::mat4 Camera::getViewMatrix() {
    return viewMatrix;
}

glm::mat4 Camera::getProjectionMatrix() {
    return projectionMatrix;
}

void Camera::move(char key, float deltaTime) {
    float speed = 2.5f * deltaTime;

    if (key == 'W') position += front * speed;
    if (key == 'S') position -= front * speed;
    if (key == 'A') position -= glm::normalize(glm::cross(front, up)) * speed;
    if (key == 'D') position += glm::normalize(glm::cross(front, up)) * speed;

    viewMatrix = glm::lookAt(position, position + front, up);

    notify(1);
}

void Camera::look(float xOffset, float yOffset) {
    float sensitivity = 0.1f;
    xOffset *= sensitivity;
    yOffset *= sensitivity;

    yaw += xOffset;
    pitch += yOffset;

    // Omez �hel kamery, aby se �nep�eklopila�
    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;

    glm::vec3 newFront;
    newFront.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    newFront.y = sin(glm::radians(pitch));
    newFront.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    front = glm::normalize(newFront);

    viewMatrix = glm::lookAt(position, position + front, up);

    notify(2);
}

void Camera::update(float aspectRatio) {
    // Nastav z�kladn� perspektivn� projekci
    projectionMatrix = glm::perspective(
        glm::radians(45.0f), // FOV
        aspectRatio,
        0.1f,
        100.0f
    );

    // Pokud m� shader, m��e� mu rovnou p�edat data
    if (shaderProgram) {
        shaderProgram->setCamera(this);
    }

    notify(3);
}

glm::vec3 Camera::getPosition() const {
    return position;
}
