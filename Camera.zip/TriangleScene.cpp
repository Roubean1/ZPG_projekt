#include "TriangleScene.h"
#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

void TriangleScene::init() {
    float trianglePoints[] = {
        -0.5f, -0.5f, 0.0f,  1.0f, 0.5f, 0.2f,
         0.5f, -0.5f, 0.0f,  1.0f, 0.5f, 0.2f,
         0.0f,  0.5f, 0.0f,  1.0f, 0.5f, 0.2f
    };

    auto triangleModel = std::make_shared<Model>();
    triangleModel->loadModel(trianglePoints, sizeof(trianglePoints) / sizeof(float));

    auto shader = std::make_shared<ShaderProgram>(); // default konstruktor
    if (!shader->loadShadersFromFiles(CONSTANT_VERTEX, CONSTANT_FRAGMENT)) {
        std::cerr << "Failed to load constant shader!" << std::endl;
        return;
    }
    shader->use();
    shader->setUniform("objectColor", glm::vec3(1.0f, 0.5f, 0.2f));

    auto transform = std::make_shared<CompositeTransform>();
    addObject(DrawableObject(triangleModel, shader, transform));
}

void TriangleScene::update(float deltaTime) {
    rotationAngle += deltaTime * 50.0f;

    auto& objects = getObjects();
    if (!objects.empty()) {
        auto composite = std::make_shared<CompositeTransform>();
        composite->addTransform(std::make_shared<Rotate>(glm::radians(rotationAngle), glm::vec3(0.0f, 0.0f, 1.0f)));
        objects[0].setTransform(composite); // p�es setter
    }
}
