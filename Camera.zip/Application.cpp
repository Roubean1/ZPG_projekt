﻿#include "Application.h"
#include <iostream>

Application* Application::instance = nullptr;

Application::Application() : window(nullptr) {}

Application::~Application() {
    if (window) {
        glfwDestroyWindow(window);
    }
    glfwTerminate();
}

Application* Application::getInstance() {
    if (!instance) {
        instance = new Application();
    }
    return instance;
}

void Application::destroyInstance() {
    if (instance) {
        delete instance;
        instance = nullptr;
    }
}

void Application::error_callback(int error, const char* description) {
    fputs(description, stderr);
}

void Application::key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
    else if (key >= GLFW_KEY_1 && key <= GLFW_KEY_9 && action == GLFW_PRESS) {
        int sceneIndex = key - GLFW_KEY_1;
        Application::getInstance()->switchScene(sceneIndex);
    }
}

void Application::window_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
    Application* app = Application::getInstance();

    // 🔹 přepočet projekční matice při změně velikosti okna
    if (app->camera) {
        float aspect = static_cast<float>(width) / static_cast<float>(height);
        app->camera->update(aspect);  // přepočet projekce + notify(1)
    }
}

void Application::mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
    Application::getInstance()->processMouseButton(button, action);
}

void Application::processMouseButton(int button, int action) {
    if (button == GLFW_MOUSE_BUTTON_RIGHT) {
        if (action == GLFW_PRESS) {
            rightMouseButtonPressed = true;
            glfwGetCursorPos(window, &lastMouseX, &lastMouseY);
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        }
        else if (action == GLFW_RELEASE) {
            rightMouseButtonPressed = false;
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
        }
    }
}

void Application::cursor_pos_callback(GLFWwindow* window, double mouseX, double mouseY) {
    Application* app = Application::getInstance();
    if (!app->rightMouseButtonPressed || !app->camera) return;

    float xOffset = static_cast<float>(mouseX - app->lastMouseX);
    float yOffset = static_cast<float>(app->lastMouseY - mouseY); // invert Y for OpenGL

    app->lastMouseX = mouseX;
    app->lastMouseY = mouseY;

    app->camera->look(xOffset, yOffset);
}


void Application::processInput(float deltaTime) {
    if (!camera) return;

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) camera->move('W', deltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) camera->move('S', deltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) camera->move('A', deltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) camera->move('D', deltaTime);
}

bool Application::initialization() {
    glfwSetErrorCallback(error_callback);
    if (!glfwInit()) {
        fprintf(stderr, "ERROR: could not start GLFW3\n");
        return false;
    }

    window = glfwCreateWindow(1280, 720, "ZPG - OpenGL", NULL, NULL);
    if (!window) {
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(window);
    glewExperimental = GL_TRUE;

    GLenum err = glewInit();
    if (err != GLEW_OK) {
        fprintf(stderr, "ERROR: %s\n", glewGetErrorString(err));
        return false;
    }

    printf("OpenGL Version: %s\n", glGetString(GL_VERSION));

    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);

    glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
    glEnable(GL_DEPTH_TEST);

    // 🔹 Nastavení callbacků
    glfwSetKeyCallback(window, key_callback);
    glfwSetCursorPosCallback(window, cursor_pos_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);
    glfwSetWindowSizeCallback(window, window_size_callback);

    // 🔹 Inicializace kamery a světla
    camera = std::make_shared<Camera>(nullptr);
    float aspect = static_cast<float>(width) / static_cast<float>(height);
    camera->update(aspect);

    light = std::make_shared<Light>();
    light->setPosition(glm::vec3(5.0f, 5.0f, 5.0f));
    light->setColor(glm::vec3(1.0f));

    return true;
}

void Application::createShaders() {}
void Application::createModels() {}

void Application::createScenes() {
    scenes.push_back(std::make_shared<TriangleScene>());
    scenes.push_back(std::make_shared<SpheresScene>());
    scenes.push_back(std::make_shared<ForestScene>());
    scenes.push_back(std::make_shared<SolarSystemScene>());

    for (auto& scene : scenes) {
        scene->init();

        for (auto& obj : scene->getObjects()) {
            auto shader = obj.getShader();
            if (shader) {
                if (camera) shader->setCamera(camera.get());
                if (light)  shader->setLight(light.get());
            }
        }
    }
}

void Application::run() {
    createScenes();
    lastTime = glfwGetTime();

    while (!glfwWindowShouldClose(window)) {
        float currentTime = glfwGetTime();
        float deltaTime = currentTime - lastTime;
        lastTime = currentTime;

        processInput(deltaTime);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        if (currentScene >= 0 && currentScene < scenes.size()) {
            scenes[currentScene]->update(deltaTime);
            scenes[currentScene]->draw();
        }

        glfwPollEvents();
        glfwSwapBuffers(window);
    }
}

void Application::switchScene(int sceneIndex) {
    if (sceneIndex >= 0 && sceneIndex < scenes.size()) {
        currentScene = sceneIndex;
    }
}
