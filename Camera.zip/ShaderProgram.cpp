#include "ShaderProgram.h"

ShaderProgram::~ShaderProgram() {
    if (id != 0) glDeleteProgram(id);
}

void ShaderProgram::addShader(std::shared_ptr<Shader> shader) {
    shaders.push_back(shader);
}

bool ShaderProgram::loadShadersFromFiles(const std::string& vertexPath, const std::string& fragmentPath) {
    auto vertexShader = std::make_shared<Shader>(GL_VERTEX_SHADER);
    if (!vertexShader->loadFromFile(vertexPath)) return false;

    auto fragmentShader = std::make_shared<Shader>(GL_FRAGMENT_SHADER);
    if (!fragmentShader->loadFromFile(fragmentPath)) return false;

    shaders.clear();
    shaders.push_back(vertexShader);
    shaders.push_back(fragmentShader);

    return linkProgram(); // tady voláme link
}

bool ShaderProgram::linkProgram() {
    id = glCreateProgram();
    for (auto& shader : shaders) {
        glAttachShader(id, shader->getId());
    }
    glLinkProgram(id);

    GLint success;
    glGetProgramiv(id, GL_LINK_STATUS, &success);
    if (!success) {
        GLchar infoLog[512];
        glGetProgramInfoLog(id, 512, NULL, infoLog);
        std::cerr << "Shader program linking failed:\n" << infoLog << std::endl;
        return false;
    }

    for (auto& shader : shaders) {
        glDetachShader(id, shader->getId());
    }
    return true;
}

void ShaderProgram::use() {
    if (id != 0) glUseProgram(id);
}

void ShaderProgram::setUniform(const std::string& name, const glm::mat4& matrix) {
    GLint loc = glGetUniformLocation(id, name.c_str());
    if (loc != -1) glUniformMatrix4fv(loc, 1, GL_FALSE, glm::value_ptr(matrix));
}

void ShaderProgram::setUniform(const std::string& name, const glm::vec3& vector) {
    GLint loc = glGetUniformLocation(id, name.c_str());
    if (loc != -1) glUniform3f(loc, vector.x, vector.y, vector.z);
}

void ShaderProgram::setUniform(const std::string& name, const glm::vec4& vector) {
    GLint loc = glGetUniformLocation(id, name.c_str());
    if (loc != -1) glUniform4f(loc, vector.x, vector.y, vector.z, vector.w);
}

void ShaderProgram::setUniform(const std::string& name, float value) {
    GLint loc = glGetUniformLocation(id, name.c_str());
    if (loc != -1) glUniform1f(loc, value);
}

void ShaderProgram::setUniform(const std::string& name, int value) {
    GLint loc = glGetUniformLocation(id, name.c_str());
    if (loc != -1) glUniform1i(loc, value);
}

void ShaderProgram::setUniform(const std::string& name, bool value) {
    GLint loc = glGetUniformLocation(id, name.c_str());
    if (loc != -1) glUniform1i(loc, value);
}

void ShaderProgram::setCamera(Camera* cam) { camera = cam; }
void ShaderProgram::setLight(Light* l) { light = l; }

void ShaderProgram::onNotify(int eventType) {
    if (eventType == 1 && camera) updateCameraUniforms(camera);
    else if (eventType == 2 && light) updateLightUniforms(light);
}

void ShaderProgram::updateCameraUniforms(Camera* camera) {
    use();
    setUniform("viewMatrix", camera->getViewMatrix());
    setUniform("projectionMatrix", camera->getProjectionMatrix());
    setUniform("viewPos", camera->getPosition());
}

void ShaderProgram::updateLightUniforms(Light* light) {
    use();
    setUniform("light.position", light->getPosition());
    setUniform("light.color", light->getColor());
}
