﻿#pragma once

#include <string>
#include <vector>
#include <memory>
#include <iostream>
#include <GL/glew.h>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "Shader.h"
#include "Camera.h"
#include "Light.h"

class ShaderProgram {
public:
    // --- Konstruktory ---
    ShaderProgram() = default; // prázdný konstruktor

    ShaderProgram(const std::string& shaderName) {
        std::string vertexPath = "shaders/" + shaderName + ".vert";
        std::string fragmentPath = "shaders/" + shaderName + ".frag";

        if (!loadShadersFromFiles(vertexPath, fragmentPath)) {
            std::cerr << "Failed to load shader program: " << shaderName << std::endl;
        }
    }


    ~ShaderProgram();

    // --- Metody pro práci se shadery ---
    void addShader(std::shared_ptr<Shader> shader);
    bool loadShadersFromFiles(const std::string& vertexPath, const std::string& fragmentPath);
    bool linkProgram();
    void use();

    // --- Uniformy ---
    void setUniform(const std::string& name, const glm::mat4& matrix);
    void setUniform(const std::string& name, const glm::vec3& vector);
    void setUniform(const std::string& name, const glm::vec4& vector);
    void setUniform(const std::string& name, float value);
    void setUniform(const std::string& name, int value);
    void setUniform(const std::string& name, bool value);

    // --- Kamera a světlo ---
    void setCamera(Camera* cam);
    void setLight(Light* l);

    // --- Observer metoda ---
    void onNotify(int eventType);

private:
    GLuint id = 0;
    std::vector<std::shared_ptr<Shader>> shaders;
    Camera* camera = nullptr;
    Light* light = nullptr;

    void updateCameraUniforms(Camera* camera);
    void updateLightUniforms(Light* light);
};
