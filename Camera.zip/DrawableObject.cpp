#include "DrawableObject.h"

DrawableObject::DrawableObject(
    std::shared_ptr<Model> model,
    std::shared_ptr<ShaderProgram> shader,
    std::shared_ptr<Transform> transform)
    : model(model), shader(shader), transform(transform) {
}

void DrawableObject::draw() {
    shader->use();
    if (transform) {
        shader->setUniform("modelMatrix", transform->getMatrix());
    }
    model->draw();
}
