#pragma once
#include "OpenGL_Include.h"
#include "Model.h"
#include "ShaderProgram.h"
#include "Transform.h"
#include <memory>

class DrawableObject
{
private:
    std::shared_ptr<Model> model;
    std::shared_ptr<ShaderProgram> shader;
    std::shared_ptr<Transform> transform;

public:
    DrawableObject(
        std::shared_ptr<Model> model,
        std::shared_ptr<ShaderProgram> shader,
        std::shared_ptr<Transform> transform
    );

    void draw();

    // P��stup k transform
    std::shared_ptr<Transform> getTransform() const { return transform; }
    void setTransform(std::shared_ptr<Transform> t) { transform = t; }

    std::shared_ptr<ShaderProgram> getShader() const { return shader; }
};
