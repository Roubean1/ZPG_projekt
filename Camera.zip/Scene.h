#pragma once
#include "OpenGL_Include.h"
#include "DrawableObject.h"
#include "CompositeTransform.h"
#include "Rotate.h"
#include "Scale.h"
#include "Translate.h"

#include "Models/tree.h"
#include "Models/gift.h"
#include "Models/sphere.h"
#include "Models/bushes.h"
#include "Models/plain.h"

const std::string SHADER_PATH = "shaders/";
const std::string CONSTANT_VERTEX = SHADER_PATH + "constant.vert";
const std::string CONSTANT_FRAGMENT = SHADER_PATH + "constant.frag";
const std::string LAMBERT_VERTEX = SHADER_PATH + "lambert.vert";
const std::string LAMBERT_FRAGMENT = SHADER_PATH + "lambert.frag";
const std::string PHONG_VERTEX = SHADER_PATH + "phong.vert";
const std::string PHONG_FRAGMENT = SHADER_PATH + "phong.frag";
const std::string BLINN_VERTEX = SHADER_PATH + "blinn.vert";
const std::string BLINN_FRAGMENT = SHADER_PATH + "blinn.frag";

class Scene {
protected:
    std::vector<DrawableObject> objects;
public:
    virtual ~Scene() = default;
    virtual void init() = 0;
    virtual void update(float deltaTime) = 0;
    void addObject(const DrawableObject& object);
    void draw();

    std::vector<DrawableObject>& getObjects() { return objects; }
    const std::vector<DrawableObject>& getObjects() const { return objects; }
};