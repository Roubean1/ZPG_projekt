#pragma once
#include "OpenGL_Include.h"
#include "Subject.h"

class ShaderProgram;

class Camera : public Subject {
private:
    ShaderProgram* shaderProgram;

    glm::vec3 position;
    glm::vec3 front;
    glm::vec3 up;

    float yaw;
    float pitch;

    glm::mat4 viewMatrix;
    glm::mat4 projectionMatrix;

public:
    Camera(ShaderProgram* shaderProgram);

    glm::mat4 getViewMatrix();
    glm::mat4 getProjectionMatrix();

    void move(char key, float deltaTime);
    void look(float xOffset, float yOffset);
    void update(float aspectRatio);

    glm::vec3 getPosition() const;
};
