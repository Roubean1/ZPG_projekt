#include "Scene.h"


void Scene::addObject(const DrawableObject& object) {
    objects.push_back(object);
}

void Scene::draw() {
    for (auto& obj : objects) {
        obj.draw();
    }
}