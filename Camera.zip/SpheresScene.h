#pragma once
#include "Scene.h"
#include "OpenGL_Include.h"

class SpheresScene : public Scene {
public:
    void init() override;
    void update(float deltaTime) override;
};