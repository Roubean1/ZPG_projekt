#pragma once
#include "Scene.h"

class SolarSystemScene : public Scene {
private:
    float earthOrbitAngle = 0.0f;
    float moonOrbitAngle = 0.0f;
    float earthRotationAngle = 0.0f;
    float moonRotationAngle = 0.0f;

public:
    void init() override;
    void update(float deltaTime) override;
};