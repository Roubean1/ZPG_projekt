#include "Light.h"
#include "ShaderProgram.h"

Light::Light(ShaderProgram* shaderProgram, glm::vec3 position, glm::vec3 color)
    : shaderProgram(shaderProgram), position(position), color(color) {
}

void Light::setPosition(const glm::vec3& newPosition) {
    position = newPosition;
    if (shaderProgram) {
        shaderProgram->setUniform("light.position", position);
    }
    notify(2); // informuje pozorovatele (nap�. ShaderProgram)
}

void Light::setColor(const glm::vec3& newColor) {
    color = newColor;
    if (shaderProgram) {
        shaderProgram->setUniform("light.color", color);
    }
    notify(2);
}
