#pragma once
#include "OpenGL_Include.h"
#include "ShaderProgram.h"
#include  "Model.h"
#include "Scene.h"
#include "Camera.h"
#include "Light.h"
#include <iostream>

#include "ForestScene.h"
#include "TriangleScene.h"
#include "SpheresScene.h"
#include "SolarSystemScene.h"

class Application
{
private:
	static Application* instance;
    GLFWwindow* window;
    std::vector<std::shared_ptr<ShaderProgram>> shaderPrograms;
    std::vector<std::shared_ptr<Model>> models;
    std::vector<std::shared_ptr<Scene>> scenes;
    std::shared_ptr<Camera> camera;
    std::shared_ptr<Light> light;
    int currentScene = 0;
    float lastTime = 0.0f;

    bool rightMouseButtonPressed = false;
    double lastMouseX = 0.0, lastMouseY = 0.0;

    Application();
public:
    ~Application();

    static Application* getInstance();
    static void destroyInstance();

    static void error_callback(int error, const char* description);
    static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
    static void window_size_callback(GLFWwindow* window, int width, int height);
    static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
    static void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

    static void cursor_pos_callback(GLFWwindow* window, double mouseX, double mouseY);
    void processMouseButton(int button, int action);
    void processScroll(double xoffset, double yoffset);

    bool initialization();
    void createShaders();
    void createModels();
    void createScenes();
    void run();
    void switchScene(int sceneIndex);
    void processInput(float deltaTime);

    Camera* getCamera() const { return camera.get(); }
    Light* getLight() const { return light.get(); }
};

