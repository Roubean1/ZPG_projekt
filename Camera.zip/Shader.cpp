#include "Shader.h"
#include <fstream>
#include <sstream>
#include <iostream>

Shader::Shader(GLenum type, const std::string& source)
    : shaderID(0), type(type), source(source)
{
    shaderID = glCreateShader(type);
}

Shader::Shader(GLenum type)
    : shaderID(0), type(type)
{
    shaderID = glCreateShader(type);
}

Shader::~Shader()
{
    if (shaderID != 0)
        glDeleteShader(shaderID);
}

bool Shader::compile()
{
    if (shaderID == 0)
    {
        std::cerr << "Shader compile error: invalid shader ID!" << std::endl;
        return false;
    }

    const char* src = source.c_str();
    glShaderSource(shaderID, 1, &src, nullptr);
    glCompileShader(shaderID);

    GLint success = 0;
    glGetShaderiv(shaderID, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        GLint logLen = 0;
        glGetShaderiv(shaderID, GL_INFO_LOG_LENGTH, &logLen);
        std::string infoLog(logLen, ' ');
        glGetShaderInfoLog(shaderID, logLen, nullptr, &infoLog[0]);
        std::cerr << "Shader compilation failed:\n" << infoLog << std::endl;
        return false;
    }

    return true;
}

bool Shader::loadFromFile(const std::string& filename)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "Failed to open shader file: " << filename << std::endl;
        return false;
    }

    std::stringstream buffer;
    buffer << file.rdbuf();
    source = buffer.str();

    return compile();
}

void Shader::createShaderFromFile(GLenum shaderType, const std::string& shaderFile)
{
    type = shaderType;
    shaderID = glCreateShader(shaderType);
    loadFromFile(shaderFile);
}

void Shader::createShader(GLenum shaderType, const std::string& shaderCode)
{
    type = shaderType;
    shaderID = glCreateShader(shaderType);
    source = shaderCode;
    compile();
}

void Shader::attachShader(GLuint programID)
{
    if (shaderID != 0)
    {
        glAttachShader(programID, shaderID);
    }
    else
    {
        std::cerr << "Cannot attach shader: invalid shader ID!" << std::endl;
    }
}
