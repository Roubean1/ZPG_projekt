#include "SolarSystemScene.h"
#include <iostream>
#include <glm/glm.hpp>
#include <glm/gtc/constants.hpp>

void SolarSystemScene::init() {
    auto sphereModel = std::make_shared<Model>();
    sphereModel->loadModel(sphere, sizeof(sphere) / sizeof(float));

    // Sun
    auto sunShader = std::make_shared<ShaderProgram>();
    if (!sunShader->loadShadersFromFiles(CONSTANT_VERTEX, CONSTANT_FRAGMENT)) return;
    sunShader->use();
    sunShader->setUniform("objectColor", glm::vec3(1.0f, 0.8f, 0.0f));

    auto sunComposite = std::make_shared<CompositeTransform>();
    sunComposite->addTransform(std::make_shared<Translate>(glm::vec3(0.0f)));
    sunComposite->addTransform(std::make_shared<Scale>(glm::vec3(2.0f)));
    addObject(DrawableObject(sphereModel, sunShader, sunComposite));

    // Earth
    auto earthShader = std::make_shared<ShaderProgram>();
    if (!earthShader->loadShadersFromFiles(PHONG_VERTEX, PHONG_FRAGMENT)) return;
    earthShader->use();
    earthShader->setUniform("objectColor", glm::vec3(0.0f, 0.4f, 1.0f));

    auto earthComposite = std::make_shared<CompositeTransform>();
    earthComposite->addTransform(std::make_shared<Translate>(glm::vec3(5.0f, 0.0f, 0.0f)));
    earthComposite->addTransform(std::make_shared<Scale>(glm::vec3(0.5f)));
    addObject(DrawableObject(sphereModel, earthShader, earthComposite));

    // Moon
    auto moonShader = std::make_shared<ShaderProgram>();
    if (!moonShader->loadShadersFromFiles(PHONG_VERTEX, PHONG_FRAGMENT)) return;
    moonShader->use();
    moonShader->setUniform("objectColor", glm::vec3(0.7f, 0.7f, 0.7f));

    auto moonComposite = std::make_shared<CompositeTransform>();
    moonComposite->addTransform(std::make_shared<Translate>(glm::vec3(6.0f, 0.0f, 0.0f)));
    moonComposite->addTransform(std::make_shared<Scale>(glm::vec3(0.2f)));
    addObject(DrawableObject(sphereModel, moonShader, moonComposite));

    // Orbit shader
    auto orbitShader = std::make_shared<ShaderProgram>();
    if (!orbitShader->loadShadersFromFiles(CONSTANT_VERTEX, CONSTANT_FRAGMENT)) return;

    // Earth orbit
    std::vector<float> earthOrbitVertices;
    int segments = 64;
    float earthOrbitRadius = 5.0f;
    for (int i = 0; i <= segments; i++) {
        float angle = 2.0f * glm::pi<float>() * i / segments;
        earthOrbitVertices.push_back(cos(angle) * earthOrbitRadius);
        earthOrbitVertices.push_back(0.0f);
        earthOrbitVertices.push_back(sin(angle) * earthOrbitRadius);
        earthOrbitVertices.push_back(1.0f); // color
        earthOrbitVertices.push_back(1.0f);
        earthOrbitVertices.push_back(1.0f);
    }
    auto earthOrbitModel = std::make_shared<Model>();
    earthOrbitModel->loadModel(earthOrbitVertices.data(), earthOrbitVertices.size());
    addObject(DrawableObject(earthOrbitModel, orbitShader, std::make_shared<CompositeTransform>()));

    // Moon orbit
    std::vector<float> moonOrbitVertices;
    float moonOrbitRadius = 1.0f;
    for (int i = 0; i <= segments; i++) {
        float angle = 2.0f * glm::pi<float>() * i / segments;
        moonOrbitVertices.push_back(cos(angle) * moonOrbitRadius);
        moonOrbitVertices.push_back(0.0f);
        moonOrbitVertices.push_back(sin(angle) * moonOrbitRadius);
        moonOrbitVertices.push_back(1.0f);
        moonOrbitVertices.push_back(1.0f);
        moonOrbitVertices.push_back(1.0f);
    }
    auto moonOrbitModel = std::make_shared<Model>();
    moonOrbitModel->loadModel(moonOrbitVertices.data(), moonOrbitVertices.size());
    addObject(DrawableObject(moonOrbitModel, orbitShader, std::make_shared<CompositeTransform>()));
}

void SolarSystemScene::update(float deltaTime) {
    earthOrbitAngle += deltaTime * 30.0f;
    moonOrbitAngle += deltaTime * 60.0f;
    earthRotationAngle += deltaTime * 100.0f;
    moonRotationAngle += deltaTime * 50.0f;

    auto& objects = getObjects();

    if (objects.size() > 0) {
        auto sunComposite = std::make_shared<CompositeTransform>();
        sunComposite->addTransform(std::make_shared<Translate>(glm::vec3(0.0f)));
        sunComposite->addTransform(std::make_shared<Rotate>(glm::radians(earthRotationAngle * 0.1f), glm::vec3(0.0f, 1.0f, 0.0f)));
        sunComposite->addTransform(std::make_shared<Scale>(glm::vec3(2.0f)));
        objects[0].setTransform(sunComposite);
    }

    if (objects.size() > 1) {
        float earthX = cos(glm::radians(earthOrbitAngle)) * 5.0f;
        float earthZ = sin(glm::radians(earthOrbitAngle)) * 5.0f;

        auto earthComposite = std::make_shared<CompositeTransform>();
        earthComposite->addTransform(std::make_shared<Translate>(glm::vec3(earthX, 0.0f, earthZ)));
        earthComposite->addTransform(std::make_shared<Rotate>(glm::radians(earthRotationAngle), glm::vec3(0.0f, 1.0f, 0.0f)));
        earthComposite->addTransform(std::make_shared<Scale>(glm::vec3(0.5f)));
        objects[1].setTransform(earthComposite);
    }

    if (objects.size() > 2) {
        float earthX = cos(glm::radians(earthOrbitAngle)) * 5.0f;
        float earthZ = sin(glm::radians(earthOrbitAngle)) * 5.0f;

        float moonX = cos(glm::radians(moonOrbitAngle)) * 1.0f;
        float moonZ = sin(glm::radians(moonOrbitAngle)) * 1.0f;

        auto moonComposite = std::make_shared<CompositeTransform>();
        moonComposite->addTransform(std::make_shared<Translate>(glm::vec3(earthX + moonX, 0.0f, earthZ + moonZ)));
        moonComposite->addTransform(std::make_shared<Rotate>(glm::radians(moonRotationAngle), glm::vec3(0.0f, 1.0f, 0.0f)));
        moonComposite->addTransform(std::make_shared<Scale>(glm::vec3(0.2f)));
        objects[2].setTransform(moonComposite);
    }
}
