#pragma once
class Observer
{
public:
	virtual ~Observer() = default;
	virtual void onNotify(int eventType) = 0;
};