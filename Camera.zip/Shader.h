#pragma once
#include "OpenGL_Include.h"
#include <string>


class Shader
{
private:
	GLuint shaderID;
	GLenum type;

	std::string source;
public:
    Shader(GLenum type, const std::string& source);
    Shader(GLenum type);
    ~Shader();

    bool compile();
    bool loadFromFile(const std::string& filename);
    void createShaderFromFile(GLenum shaderType, const std::string& shaderFile);
    void createShader(GLenum shaderType, const std::string& shaderCode);
    void attachShader(GLuint programID);

	GLuint getId() const { return shaderID; }
	GLenum getType() const { return type; }
};